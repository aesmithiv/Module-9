const express = require('express');
require('dotenv').config();
const db = require('./models');

const app = express();
app.use(express.json());

app.use('/api/users', require('./routes/userRoutes'));
app.use('/api/posts', require('./routes/postRoutes'));
app.use('/api/comments', require('./routes/commentRoutes'));

const PORT = process.env.PORT || 8081;

db.sequelize.sync().then(() => {
  app.listen(PORT, () => console.log(`✅ MySQL API running on port ${PORT}`));
});
