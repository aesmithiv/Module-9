const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/dbConnect');

const db = {};
db.sequelize = sequelize;
db.Sequelize = Sequelize;

db.User = require('./user')(sequelize, DataTypes);
db.Post = require('./post')(sequelize, DataTypes);
db.Comment = require('./comment')(sequelize, DataTypes);

// Associations
db.User.hasMany(db.Post);
db.Post.belongsTo(db.User);

db.User.hasMany(db.Comment);
db.Comment.belongsTo(db.User);

db.Post.hasMany(db.Comment);
db.Comment.belongsTo(db.Post);

module.exports = db;
