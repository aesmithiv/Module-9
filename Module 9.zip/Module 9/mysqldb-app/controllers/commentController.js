const db = require('../models');
const Comment = db.Comment;

exports.createComment = async (req, res) => {
  const comment = await Comment.create(req.body);
  res.status(201).json(comment);
};

exports.getAllComments = async (req, res) => {
  const comments = await Comment.findAll({ include: [db.User, db.Post] });
  res.json(comments);
};
