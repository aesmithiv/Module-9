const db = require('../models');
const Post = db.Post;

exports.createPost = async (req, res) => {
  const post = await Post.create(req.body);
  res.status(201).json(post);
};

exports.getAllPosts = async (req, res) => {
  const posts = await Post.findAll({ include: db.User });
  res.json(posts);
};
