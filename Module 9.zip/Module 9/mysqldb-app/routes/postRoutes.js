const express = require('express');
const router = express.Router();
const controller = require('../controllers/postController');

router.post('/', controller.createPost);
router.get('/', controller.getAllPosts);

module.exports = router;
