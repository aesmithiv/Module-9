const express = require('express');
const router = express.Router();
const controller = require('../controllers/commentController');

router.post('/', controller.createComment);
router.get('/', controller.getAllComments);

module.exports = router;
