const express = require('express');
const axios = require('axios');

const app = express();
const PORT = 3002;

app.get('/api/bitcoin', async (req, res) => {
  const currency = req.query.currency || 'usd';
  const url = `https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=${currency}`;

  try {
    const response = await axios.get(url);
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch Bitcoin data' });
  }
});

app.listen(PORT, () => {
  console.log(`✅ Microservice API running at http://localhost:${PORT}`);
});
