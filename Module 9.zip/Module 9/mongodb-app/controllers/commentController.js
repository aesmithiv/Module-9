const Comment = require('../models/comment');

exports.createComment = async (req, res) => {
  const comment = new Comment(req.body);
  await comment.save();
  res.status(201).json(comment);
};

exports.getAllComments = async (req, res) => {
  const comments = await Comment.find().populate('userId').populate('postId');
  res.json(comments);
};

exports.getCommentById = async (req, res) => {
  const comment = await Comment.findById(req.params.id).populate('userId').populate('postId');
  res.json(comment);
};

exports.updateComment = async (req, res) => {
  const comment = await Comment.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(comment);
};

exports.deleteComment = async (req, res) => {
  await Comment.findByIdAndDelete(req.params.id);
  res.json({ message: 'Comment deleted' });
};
